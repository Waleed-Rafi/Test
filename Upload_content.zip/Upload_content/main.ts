
function previewFile() {
  const content = document.querySelector(".content");
  const [file] = document.querySelector("input[type=file]").files;
  const reader = new FileReader();

  reader.addEventListener(
    "load",
    () => {
      // this will then display a text file
      content.innerText = reader.result;
      var obj = new Object();
      obj.mytext =reader.result;
      var jsonString= JSON.stringify(obj);
      fetch("https://c4c5-119-158-116-152.in.ngrok.io/api/add_message/1234", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        'Access-Control-Allow-Origin': '*',
         'Accept': 'application/json',
      },
      body: jsonString
    });
    },
    false
  );
  

  if (file) {
    reader.readAsText(file);
  }
}


